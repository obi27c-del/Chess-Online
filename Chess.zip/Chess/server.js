import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let chess
let difficulty
let color 

const app = express();
const PORT = 4242;

import { Chessboard } from "./chess_logic.js";

app.use(express.static("public")); //magic for images
app.use(express.json());

//Route for the intro page
app.get('/chess', (req, res) => {
    res.sendFile(path.join(__dirname, 'chessintro.html'));
});

//Get game page
app.get('/chess/game', (req, res) => {
    difficulty = req.query.difficulty
    color = req.query.color
    chess = new Chessboard(color, difficulty)

    res.sendFile(path.join(__dirname, 'chessgame.html'));
});

// Send board state as JSON (I think, also should be added to based on info needed)
app.get('/chess/game/state', (req, res) => {
    console.log("STATE REQUEST — chess =", chess);

    if (!chess) {
        console.log("ERROR: chess is undefined");
        return res.status(400).json({ error: "Game not initialized" });
    }

    try {
        const board = chess.getCurrentBoard();
        const moves = chess.getAllMoves();
        const color = chess.getPlayerColor();

        res.json({
            board,
            playerColor: color,
            movesGrid: moves
        });
    } catch (err) {
        console.error("STATE ROUTE CRASH:", err);
        res.status(500).json({ error: "Server crash inside state" });
    }
});

app.post('/chess/game/move', async (req, res) => {
    if (!chess) return res.status(400).json({ error: "No active game" });

    let { fromX, fromY, toX, toY } = req.body;

    const ok = chess.makeMove(fromX, fromY, toX, toY, true);
    if (!ok) return res.json({ ok: false });

    // BOT MOVE
    await chess.makeBotMove();

    // Return updated board
    return res.json({
        ok: true,
        board: chess.getCurrentBoard()
    });
});

//Start the server.
//This is the only tested part, this DOES run server. I PROMISE THIS TIME.
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});

