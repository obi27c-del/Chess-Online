import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let chess
let difficulty
let color 

const app = express();
const PORT = 4242;

import { Chessboard } from "./chess_logic.js";

app.use(express.static("public")); 
app.use(express.json());

app.get('/chess', (req, res) => {
    res.sendFile(path.join(__dirname, 'chessintro.html'));
});

app.get('/chess/game', (req, res) => {
    difficulty = req.query.difficulty
    color = req.query.color
    chess = new Chessboard(color, difficulty)

    res.sendFile(path.join(__dirname, 'chessgame.html'));
});

app.get('/chess/game/state', (req, res) => {
    console.log("STATE REQUEST — chess =", chess);

    if (!chess) {
        console.log("ERROR: chess is undefined");
        return res.status(400).json({ error: "Game not initialized" });
    }

    try {
        const board = (color === "b")
            ? chess.getFlippedBoard()
            : chess.getCurrentBoard()

        const moves = chess.getAllMoves()

        const playerColor = chess.getPlayerColor()

        const gameState = chess.isGameOver()

        res.json({
            board,
            playerColor,
            movesGrid: moves,
            gameState
        });

    } catch (err) {
        console.error("STATE ROUTE CRASH:", err);
        res.status(500).json({ error: "Server crash inside state" });
    }
});

app.post('/chess/game/move', async (req, res) => {
    if (!chess) return res.status(400).json({ error: "No active game" });

    let { fromX, fromY, toX, toY } = req.body;

    const ok = chess.makeMove(fromX, fromY, toX, toY, true);
    if (!ok) return res.json({ ok: false });

    await new Promise(r => setTimeout(r, 600));

    const botResult = await chess.makeBotMove();

    return res.json({
        ok: true,
        board: chess.getCurrentBoard(),
        botMove: botResult  
    });
});

app.post("/chess/game/promote", (req, res) => {
    const { x, y, piece } = req.body;
    const ok = chess.promotePawn(x, y, piece);
    res.json({ ok });
});

app.get("/chess/game/firstBotMove", (req, res) => {
    const botResult = chess.makeBotMove().then(() => {
        return res.json({
        ok: true,
        board: chess.getCurrentBoard(),
        botMove: botResult  
    });
    });
})

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
